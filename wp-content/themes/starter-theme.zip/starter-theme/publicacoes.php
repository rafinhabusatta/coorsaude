<!-- Template name: Publicacoes -->
<?php get_header(); ?>
    <div class="container-fluid">
        <div class="contato">
            <div class="row">
                <div class="col-12 col-md-6">
                    <img src="<?php bloginfo("template_directory"); ?>/assets/under-construction.svg" alt="Ícone de página em construção">
                </div>
                <div class="col-12 col-md-6 m-auto">
                    <h2>Ops, parece que essa página ainda está em construção.</h2>
                </div>
            </div>
        </div>
    </div>
<?php get_footer(); ?>